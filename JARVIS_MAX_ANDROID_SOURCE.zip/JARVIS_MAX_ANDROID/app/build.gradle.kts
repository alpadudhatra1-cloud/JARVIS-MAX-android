plugins { id("com.android.application") }

android { namespace = "com.jarvis.max"; compileSdk = 35
    defaultConfig { applicationId = "com.jarvis.max"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
