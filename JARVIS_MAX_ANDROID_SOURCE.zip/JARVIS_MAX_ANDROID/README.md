# JARVIS MAX — Android Studio Project

This is the Android-native shell for the JARVIS MAX web UI. It bundles the current JARVIS MAX HTML inside the APK and starts a foreground Android service so the app can remain active when its UI is closed.

## Build
1. Open this folder in Android Studio.
2. Let Android Studio download the Android Gradle Plugin/Gradle dependencies.
3. Use an Android SDK with API 35 installed.
4. Connect an Android device or start an emulator.
5. Build > Build APK(s).

## Current capabilities
- JARVIS MAX HUD UI bundled locally — no web hosting required.
- LocalStorage data stays on the device.
- Native foreground service notification keeps a background service alive.
- Microphone permission is requested for voice features.
- Existing tasks, notes, JEE dashboard, focus timer, calculator and commands remain in the bundled UI.

## Important Android limitation
This project does NOT falsely promise a guaranteed always-listening "Hey JARVIS" wake word. Android background microphone access is restricted and continuous listening can be battery-intensive. A production-grade wake-word system should use an on-device keyword-spotting engine or Android assistant integration.

The bundled web UI's JavaScript timers/voice recognition are still WebView-based. For truly reliable background alarms, reminders, and a native always-available voice pipeline, those pieces should be moved into Android services/AlarmManager/WorkManager in a later version.
