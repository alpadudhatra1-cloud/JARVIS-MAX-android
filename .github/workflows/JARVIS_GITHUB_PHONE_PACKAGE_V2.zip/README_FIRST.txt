JARVIS MAX 2.0 — PHONE-ONLY UPDATE

This package fixes the APK voice problem by moving voice input/output from WebView browser APIs to native Android SpeechRecognizer + TextToSpeech.

1. In your GitHub repo JARVIS-MAX-ANDROID, replace the existing JARVIS_MAX_ANDROID_SOURCE.zip with the new file from this package.
2. Keep your existing .github/workflows/build-apk.yml workflow.
3. Open Actions → Build JARVIS APK → Run workflow.
4. Wait for the green Success result.
5. Open the run Summary → Artifacts → jarvis-debug-apk.
6. Download the artifact ZIP, extract it, and install app-debug.apk.

After installing:
- Allow microphone permission when Android asks.
- Open JARVIS and tap ACTIVATE VOICE once.
- Test with: “What time is it”.
- Keep the JARVIS notification/service enabled for background availability.

The app is upgraded to version 2.0.
