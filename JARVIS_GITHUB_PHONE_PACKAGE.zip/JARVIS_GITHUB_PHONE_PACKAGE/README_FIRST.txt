JARVIS MAX — PHONE-ONLY GITHUB BUILD

1. In your GitHub repository, upload JARVIS_MAX_ANDROID_SOURCE.zip and commit it.
2. Create this folder/path in GitHub: .github/workflows/
3. Create a file named build-apk.yml there.
4. Copy/paste the contents of BUILD_APK_WORKFLOW.yml into it and commit.
5. Open Actions → Build JARVIS APK → Run workflow.
6. When green, open the run → Artifacts → jarvis-debug-apk → download.
7. Open the downloaded APK and install it.

Do NOT create a Codespace.
