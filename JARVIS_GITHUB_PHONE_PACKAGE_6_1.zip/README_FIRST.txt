JARVIS MAX 6.1 — PHONE/GITHUB PACKAGE

Use your EXISTING JARVIS-MAX-ANDROID repository. Do NOT create a new repo.

Upload JARVIS_MAX_ANDROID_SOURCE_6_1.zip to the repo root, then update your GitHub Actions workflow to build that ZIP.

6.1 focus:
- Natural intent routing rather than exact command phrases
- More robust spoken math
- Native Android app launching
- Native web search
- Native countdown timer bridge
- Natural study-session commands with subject + duration
- Better task/date/JEE/basic conversation handling

This is still local-first. Full open-ended AI conversation requires the optional AI endpoint.
